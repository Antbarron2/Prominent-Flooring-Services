import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Prominent Flooring Services",
  description: "Professional flooring installation, repairs, refinishing, and project support in DFW.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
