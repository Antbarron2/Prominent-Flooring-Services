"use client";

import { motion } from "framer-motion";
import {
  ArrowRight,
  CheckCircle2,
  Hammer,
  Home,
  Layers3,
  Mail,
  MapPin,
  Phone,
  ShieldCheck,
  Star,
} from "lucide-react";

const services = [
  {
    title: "Hardwood Installation",
    description:
      "Professional wood floor installation with clean layout, strong craftsmanship, and a polished finish.",
    icon: Home,
  },
  {
    title: "Repairs & Replacements",
    description:
      "From damaged boards to partial replacements, we help restore the look and strength of your flooring.",
    icon: Hammer,
  },
  {
    title: "Refinishing & Recoats",
    description:
      "Bring worn hardwood back to life with sanding, refinishing, and screen-and-recoat services.",
    icon: Layers3,
  },
  {
    title: "Project Support",
    description:
      "Reliable scheduling, clear communication, and professional service from quote to final walkthrough.",
    icon: ShieldCheck,
  },
];

const highlights = [
  "Professional presentation",
  "Clear communication",
  "Detail-driven work",
  "Built for homeowners and vendor partners",
];

const process = [
  "Request a quote",
  "We review your project",
  "Receive clear scope and pricing",
  "Professional installation or repair",
  "Final walkthrough",
];

function Button({
  children,
  href,
  variant = "solid",
}: {
  children: React.ReactNode;
  href?: string;
  variant?: "solid" | "outline";
}) {
  const base =
    "inline-flex items-center justify-center rounded-2xl px-6 py-4 text-base font-semibold transition";
  const styles =
    variant === "outline"
      ? "border border-white/20 bg-transparent text-white hover:bg-white/10"
      : "bg-white text-zinc-950 hover:bg-zinc-200";

  if (href) {
    return (
      <a href={href} className={`${base} ${styles}`}>
        {children}
      </a>
    );
  }

  return <button className={`${base} ${styles}`}>{children}</button>;
}

function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <div className={`rounded-[1.5rem] border border-white/10 bg-white/5 shadow-xl ${className}`}>{children}</div>;
}

export default function HomePage() {
  return (
    <main className="min-h-screen bg-zinc-950 text-white">
      <section className="relative overflow-hidden border-b border-white/10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(255,255,255,0.10),transparent_35%)]" />
        <div className="mx-auto max-w-7xl px-6 py-6">
          <div className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-4 py-3 backdrop-blur">
            <div>
              <div className="text-lg font-black tracking-[0.2em] md:text-xl">PROMINENT FLOORING SERVICES</div>
              <div className="text-xs text-zinc-400">A division of Prominent Renovations LLC</div>
            </div>
            <div className="hidden items-center gap-6 md:flex">
              <a href="#services" className="text-sm text-zinc-300 transition hover:text-white">Services</a>
              <a href="#about" className="text-sm text-zinc-300 transition hover:text-white">About</a>
              <a href="#process" className="text-sm text-zinc-300 transition hover:text-white">Process</a>
              <a href="#contact" className="text-sm text-zinc-300 transition hover:text-white">Contact</a>
            </div>
          </div>
        </div>

        <div className="mx-auto grid max-w-7xl gap-12 px-6 pb-20 pt-8 md:grid-cols-2 md:items-center md:pt-16">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            <div className="inline-flex items-center rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs uppercase tracking-[0.25em] text-zinc-300">
              Flooring done right
            </div>
            <h1 className="text-4xl font-black leading-tight tracking-tight md:text-6xl">
              Strong flooring work. Clean presentation. Professional results.
            </h1>
            <p className="max-w-xl text-base leading-7 text-zinc-300 md:text-lg">
              Prominent Flooring Services helps homeowners, builders, and restoration partners with dependable flooring installation, repairs, refinishing, and project support.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button href="#contact">Request a Quote</Button>
              <Button href="#services" variant="outline">View Services</Button>
            </div>
            <div className="grid gap-3 pt-4 sm:grid-cols-2">
              {highlights.map((item) => (
                <div key={item} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 p-4">
                  <CheckCircle2 className="h-5 w-5 shrink-0" />
                  <span className="text-sm text-zinc-200">{item}</span>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7 }}
            className="relative"
          >
            <div className="absolute -inset-4 rounded-[2rem] bg-white/5 blur-2xl" />
            <Card className="relative overflow-hidden rounded-[2rem] bg-zinc-900/90">
              <div className="p-8">
                <div className="mb-8 flex items-center justify-between">
                  <div>
                    <div className="text-xs uppercase tracking-[0.25em] text-zinc-400">Prominent Flooring Services</div>
                    <div className="mt-2 text-3xl font-black">Built to impress from first quote to final walkthrough.</div>
                  </div>
                  <div className="hidden rounded-2xl border border-white/10 bg-white/5 p-4 md:block">
                    <Star className="h-8 w-8" />
                  </div>
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
                    <div className="text-sm text-zinc-400">Primary focus</div>
                    <div className="mt-2 text-xl font-bold">Hardwood, repairs, refinishing</div>
                  </div>
                  <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
                    <div className="text-sm text-zinc-400">Client experience</div>
                    <div className="mt-2 text-xl font-bold">Clear, clean, professional</div>
                  </div>
                  <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
                    <div className="text-sm text-zinc-400">Who we serve</div>
                    <div className="mt-2 text-xl font-bold">Homeowners and vendor partners</div>
                  </div>
                  <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
                    <div className="text-sm text-zinc-400">Brand promise</div>
                    <div className="mt-2 text-xl font-bold">Dependable work with sharp presentation</div>
                  </div>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>
      </section>

      <section id="services" className="mx-auto max-w-7xl px-6 py-20">
        <div className="mb-10 max-w-2xl">
          <div className="text-sm uppercase tracking-[0.25em] text-zinc-400">Services</div>
          <h2 className="mt-3 text-3xl font-black md:text-5xl">What Prominent Flooring Services offers</h2>
          <p className="mt-4 text-zinc-300">
            A clean, focused offer helps people understand exactly what you do and why they should hire you.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4 }}
              >
                <Card className="h-full transition hover:-translate-y-1 hover:bg-white/10">
                  <div className="p-6">
                    <div className="mb-4 inline-flex rounded-2xl border border-white/10 bg-zinc-900 p-3">
                      <Icon className="h-6 w-6" />
                    </div>
                    <h3 className="text-xl font-bold">{service.title}</h3>
                    <p className="mt-3 text-sm leading-6 text-zinc-300">{service.description}</p>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </section>

      <section id="about" className="border-y border-white/10 bg-white/[0.03]">
        <div className="mx-auto grid max-w-7xl gap-10 px-6 py-20 md:grid-cols-2">
          <div>
            <div className="text-sm uppercase tracking-[0.25em] text-zinc-400">About</div>
            <h2 className="mt-3 text-3xl font-black md:text-5xl">A strong brand for flooring-focused work</h2>
            <p className="mt-5 max-w-xl text-base leading-7 text-zinc-300">
              Prominent Flooring Services is positioned to feel specialized, polished, and trustworthy. It presents your business as a serious flooring company while staying backed by Prominent Renovations LLC as the legal business entity.
            </p>
          </div>
          <div className="grid gap-4">
            <div className="rounded-[1.5rem] border border-white/10 bg-zinc-900/80 p-6">
              <div className="text-sm text-zinc-400">Brand</div>
              <div className="mt-2 text-2xl font-bold">Prominent Flooring Services</div>
            </div>
            <div className="rounded-[1.5rem] border border-white/10 bg-zinc-900/80 p-6">
              <div className="text-sm text-zinc-400">Legal entity</div>
              <div className="mt-2 text-2xl font-bold">Prominent Renovations LLC</div>
            </div>
            <div className="rounded-[1.5rem] border border-white/10 bg-zinc-900/80 p-6">
              <div className="text-sm text-zinc-400">Positioning</div>
              <div className="mt-2 text-2xl font-bold">Professional. Reliable. Detail-driven.</div>
            </div>
          </div>
        </div>
      </section>

      <section id="process" className="mx-auto max-w-7xl px-6 py-20">
        <div className="mb-10 max-w-2xl">
          <div className="text-sm uppercase tracking-[0.25em] text-zinc-400">Process</div>
          <h2 className="mt-3 text-3xl font-black md:text-5xl">How it works</h2>
        </div>
        <div className="grid gap-4 md:grid-cols-5">
          {process.map((step, index) => (
            <div key={step} className="rounded-[1.5rem] border border-white/10 bg-white/5 p-5">
              <div className="text-sm text-zinc-400">Step {index + 1}</div>
              <div className="mt-2 text-lg font-bold leading-6">{step}</div>
            </div>
          ))}
        </div>
      </section>

      <section id="contact" className="border-t border-white/10 bg-white/[0.03]">
        <div className="mx-auto grid max-w-7xl gap-10 px-6 py-20 md:grid-cols-2 md:items-center">
          <div>
            <div className="text-sm uppercase tracking-[0.25em] text-zinc-400">Contact</div>
            <h2 className="mt-3 text-3xl font-black md:text-5xl">Ready to quote your next flooring project</h2>
            <p className="mt-4 max-w-xl text-zinc-300">
              Replace the placeholder contact details below with your real phone number, email, and service area.
            </p>
            <div className="mt-8 space-y-4">
              <div className="flex items-center gap-3 text-zinc-200">
                <Phone className="h-5 w-5" />
                <span>(555) 555-5555</span>
              </div>
              <div className="flex items-center gap-3 text-zinc-200">
                <Mail className="h-5 w-5" />
                <span>info@prominentflooringservices.com</span>
              </div>
              <div className="flex items-center gap-3 text-zinc-200">
                <MapPin className="h-5 w-5" />
                <span>Dallas-Fort Worth, Texas</span>
              </div>
            </div>
          </div>

          <Card className="rounded-[2rem] bg-zinc-900/90">
            <div className="p-8">
              <div className="text-2xl font-black">Request a Quote</div>
              <p className="mt-2 text-sm leading-6 text-zinc-300">
                This can later be replaced with a real contact form, CRM integration, or booking flow.
              </p>
              <div className="mt-8 space-y-4">
                <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-4 text-zinc-400">Name</div>
                <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-4 text-zinc-400">Phone</div>
                <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-4 text-zinc-400">Email</div>
                <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-6 text-zinc-400">Project details</div>
                <Button>
                  Submit Request <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </section>
    </main>
  );
}
